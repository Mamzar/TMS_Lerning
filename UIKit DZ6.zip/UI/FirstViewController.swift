//
//  ViewController.swift
//  UI
//
//  Created by Иван Иванов on 18.04.22.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
       print ("FirstViewController:")
       
        
        
        
}
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print ("FirstViewController:")
    
    }
}





