//
//  ViewController.swift
//  UI
//
//  Created by Иван Иванов on 18.04.22.
//

import UIKit

class SecondViewController: UIViewController {
    
    @IBOutlet weak var upButton: UIButton!
    
    
    var View1: UIView = UIView()
    var squareView: UIView = UIView()
    var q = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
   
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
       print ("FirstViewController:")
        View1.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        
       self.view.addSubview(View1)
        squareView.frame = CGRect(x: 100, y: 100, width: 100, height: 100)
       
        squareView.backgroundColor = .blue
        View1.addSubview(squareView)
        
        
        
}
    @IBAction func Up(_ sender: UIButton) {
        squareView.frame = CGRect(x: q, y: 100, width: 100, height: 100)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print ("FirstViewController:")
    
    }
    
    
}






        



